<?php

namespace Hotel\PreSupplier;


class ReturnHotelStaticData {

public $description1 = false; //NO MANDATORY BOOL
public $description2 = false;
public $geoPoints = false;
public $ratingDescription = false;
public $images = false;
public $direct = false;
public $hotelPreference = false;
public $builtYear= false;
public $renovationYear= false;
public $floors= false;
public $noOfRooms= false;
public $luxury= false;
public $address= false;
public $zipCode= false;
public $location= false;
public $locationId= false;
public $location1= false;
public $location2= false;
public $location3= false;
public $stateName= false;
public $stateCode= false;
public $countryName= false;
public $regionName= false;
public $regionCode= false;
public $attraction= false;
public $amenitie= false;
public $leisure= false;
public $business= false;
public $transportation= false;
public $hotelPhone= false;
public $hotelCheckIn= false;
public $hotelCheckOut= false;
public $minAge= false;
public $rating= false;
public $fireSafety= false;
public $geoPoint= false;
public $chain= false;
public $lastUpdated= false;

}