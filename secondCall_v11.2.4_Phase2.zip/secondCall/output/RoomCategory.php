<?php
/**
 * Created by PhpStorm.
 * User: walterleonardo@gmail.com
 * Date: 1/13/2016
 * Time: 11:35 AM
 */

namespace Hotel\StaticData;

class RoomCategory
{
    public $code;
    public $name;
} 