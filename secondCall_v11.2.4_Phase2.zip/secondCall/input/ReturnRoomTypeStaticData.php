<?php


namespace Hotel\StaticData;


class ReturnRoomTypeStaticData
{
    public $roomAmenities;
    public $name;
    public $supplierRoomName;
    public $twin; //NO MANDATORY BOOL
    public $roomInfo;
    public $specials;
    public $roomImages;
    public $roomCategory; //new attribute
} 