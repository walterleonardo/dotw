<?php


namespace Hotel\StaticData;


class ReturnRoomTypeStaticData
{

//    public $twin;
//    public $roomAmenities;
//    public $name;
//    public $roomInfo;
    public $roomAmenities;
    public $name;
    public $twin; //NO MANDATORY BOOL
    public $roomInfo;
    public $specials;
    public $roomImages;
    public $roomCategory; //new attribute
} 