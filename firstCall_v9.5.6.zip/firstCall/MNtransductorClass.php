<?php

namespace Firts;

/*
 * Class to translate objest attributes in a string to request information from DAEMON Server.
 * January 2016
 * 
 * Enterprise MULTINUCLEO.COM
 * Created by Walter Lopez Pascual
 */
/*
 * CLASS FROM PARTNER INCLUDE ALL THE OBJETS THAT WE NEED.
 * In this case you need change this require by the files with your objets attributes.
 * You can use the differents source objets files for differents requests (by PARIS, DUBAI or DEMO)
 */
//require 'classFromPartner.php';

//require 'classFromPartner_Demo.php';

require 'classFromPartner_Demo_from_Adrian_1.php';
//require 'classFromPartner_Paris.php';
//require 'classFromPartner_Dubai.php';
/*
 * You need replace this previous require for your objets files
 */
//require 'Input.php';
//require 'HotelFilters.php';
//require 'RoomTypeFilters.php';
//require 'RoomOccupancy.php';

Class run {
    /*
     * Function to management all the classes
     * You need declare previously all the attributes and then run this Function to request to server.
     */

    function managerSupplierRequest(\Hotel\PreSupplier\Input $inputObj) {
        $server = '192.168.0.166'; //DAEMON SERVER IP or DOMAIN
        $port = 10003; //DAEMON SERVER PORT
        $aInput = $inputObj;
        $aRoomOccupancy = $inputObj->RoomOccupancy;
        $aRoomTypeFilters = $inputObj->RoomTypeFilters;
        $aHotelFilters = $inputObj->HotelFilters;
        /*
         * Creation of instance for the Ckeck CLASS.
         */
        $classCheck = new Check();
        /*
         * Check Mandatory and type attributes from all the objets needed.
         */
        //var_export($aInput);
        if (!$classCheck->mandatoryTypeInput($aInput)) {
            echo "error check input";
            return false;
        }
        if (!$classCheck->mandatoryTypeRoomOccupancy($aRoomOccupancy)) {
            echo "error check roomOccupancy";
            return false;
        }
        if (!$classCheck->mandatoryTypeRoomTypeFilters($aRoomTypeFilters)) {
            echo "error check type filter";
            return false;
        }
        if (!$classCheck->mandatoryTypeHotelFilters($aHotelFilters)) {
            echo "error check hotel filter";
            return false;
        }
        /*
         * Create an Instance of CONSTRUCTOR and give all the objets needed it
         */
        echo "\n\r";
        var_export($aInput);
        echo "\n\r";
        $contructor = new Constructor($aInput, $aRoomOccupancy, $aRoomTypeFilters, $aHotelFilters);
        /*
         * Join all the attributes from all the objets in a simple array
         */
        $contructor->insertVar();
        /*
         * Translate all the Booleans values to "Y" or "N"
         */
        $contructor->convertToBool();
        /*
         * Create the string that DAEMON Server need.
         */
        $arrayReturned = $contructor->returnArray();
        $string = $contructor->convertRequestArrayToString(array('|', ',', '~', '#'), $arrayReturned);
        /*
         * Create an Instance of ConnectorTCP and give the String and values for connection
         */
        print_r($string);
        echo "\n\r";
        $connector = new ConnectorTCP($string, $server, $port);
        /*
         * Send the String to the DAEMON Server
         */
        $connector->requestTCP();
        /*
         * Manage the answer and check Mandatory
         */
        $answerFromTCP = $connector->returnAnswerTCP();
        echo "\n\r###\n\r";
        print_r($answerFromTCP);
        echo "\n\r###\n\r";
        if ($classCheck->answer($answerFromTCP)) {
            /*
             * If the mandatory value are correct
             * we fill the array to answer
             */
            $mngAnswer = new fillArrayValues();
            if ($mngAnswer->distributeValues($connector->returnAnswerTCP())) {
                //var_dump($mngAnswer::$answerStatic);
            }
        } else {
            print_r($answerFromTCP);
            echo "error check in answer";
            return false;
        }
        /*
         * Answer in a return or send False in error.
         */
        return $mngAnswer::$answerStatic;
    }

}

/*
 * Class to make all the check that we need before and after to send the string to DAEMON
 */

class Check {

    public function mandatoryTypeInput(&$data) {
        $array = get_object_vars($data);
        unset($array['AdditionalFilters']); //DAEMON dont need it attribute
        $types = array('customerId' => 'integer', 'environment' => 'string', 'requestSource' => 'integer', 'passengerNationalityOrResidenceProvided' => 'boolean', 'hotelIds' => 'array', 'city' => 'integer', 'bookingChannelsWithAutoMapping' => 'array', 'bookingChannelTypes' => 'array', 'RoomOccupancy' => 'array', 'HotelFilters' => 'object', 'RoomTypeFilters' => 'object', 'AdditionalFilters' => 'array');
        $mandatory = array('customerId' => true, 'environment' => true, 'requestSource' => true, 'passengerNationalityOrResidenceProvided' => true, 'hotelIds' => false, 'city' => false, 'bookingChannelsWithAutoMapping' => false, 'bookingChannelTypes' => false, 'RoomOccupancy' => true, 'HotelFilters' => false, 'RoomTypeFilters' => false, 'AdditionalFilters' => false);
        foreach ($mandatory as $key => $value) {
            if ($value) {
                if (!isset($array[$key])) {
                    return false;
                }
            }
        }
        foreach ($array as $key => $value) {
            if (isset($value)) {
                if (gettype($value) != $types[$key]) {
                    return false;
                }
            }
        }
        return true;
    }

    public function mandatoryTypeRoomOccupancy(&$data) {
        $array = $data;
        $mandatory = array('adults' => true, 'children' => false, 'twin' => false, 'extraBed' => false);
        $types = array('adults' => 'integer', 'children' => 'array', 'twin' => 'boolean', 'extraBed' => 'boolean');
        //print_r($array);
        foreach ($array as $object) {
            $valueArray = get_object_vars($object);
            foreach ($mandatory as $key => $value) {
                if ($value) {
                    if (!isset($valueArray[$key])) {
                        return false;
                    }
                }
            }
            foreach ($valueArray as $key => $value) {
                if (isset($value)) {
                    if (gettype($value) != $types[$key]) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public function mandatoryTypeRoomTypeFilters(&$data) {
        if (isset($data)) {
            $array = get_object_vars($data);
            $mandatory = array('suite' => false, 'roomAmenitie' => false, 'roomId' => false, 'roomName' => false);
            $types = array('suite' => 'integer', 'roomAmenitie' => 'array', 'roomId' => 'array', 'roomName' => 'string');
            foreach ($mandatory as $key => $value) {
                if ($value) {
                    if (!isset($array[$key])) {
                        return false;
                    }
                }
            }
            foreach ($array as $key => $value) {
                if (isset($value)) {
                    if (gettype($value) != $types[$key]) {
                        return false;
                    }
                }
            }
            return true;
        }
        return true;
    }

    public function mandatoryTypeHotelFilters(&$data) {
        if (isset($data)) {
            $array = get_object_vars($data);
            $mandatory = array('rating' => false, 'luxury' => false,
                'location' => false, 'locationId' => false, 'amenitie' => false,
                'leisure' => false, 'business' => false, 'hotelPreference' => false,
                'chain' => false, 'attraction' => false, 'hotelName' => false,
                'builtYear' => false, 'renovationYear' => false, 'floors' => false,
                'noOfRooms' => false, 'fireSafety' => false, 'lastUpdated' => false);
            $types = array('rating' => 'array', 'luxury' => 'integer',
                'location' => 'string', 'locationId' => 'array', 'amenitie' => 'array',
                'leisure' => 'array', 'business' => 'array', 'hotelPreference' => 'array',
                'chain' => 'array', 'attraction' => 'string', 'hotelName' => 'string',
                'builtYear' => 'integer', 'renovationYear' => 'integer', 'floors' => 'integer',
                'noOfRooms' => 'integer', 'fireSafety' => 'integer', 'lastUpdated' => 'string');
            foreach ($mandatory as $key => $value) {
                if ($value) {
                    if (!isset($array[$key])) {
                        return false;
                    }
                }
            }
            foreach ($array as $key => $value) {
                if (isset($value)) {
                    if (gettype($value) != $types[$key]) {
                        return false;
                    }
                }
            }
            return true;
        }
        return true;
    }

    public function answer(&$data) {
        if (preg_match('/OK/', $data)) {
            //print_r($data);
            echo "\n\r";
            $arraypre = explode('|||', $data);
//            print_r($arraypre);
//            echo "\n\r";
            $array = array_splice($arraypre, 1);
            foreach ($array as $value) {
                $arrayExploded = explode(",", $value);
                if (count($arrayExploded) < 6) {
                    return false;
                }
            }
        } else {
            return false;
        }
        return true;
    }

}

/*
 * Class to join all the attributes in a multidimensional array and fill the empty values. To make a compatible string for the DAEMON
 */

class Constructor {

    Private $aInput;
    Private $aRoomOccupancy;
    Private $aRoomTypeFilters;
    Private $aHotelFilters;
    Public static $arrayConverted = array('customerId' => '', 'environment' => '', 'requestSource' => '', 'passengerNationalityOrResidenceProvided' => '', 'hotelIds' => '', 'city' => '', 'bookingChannelTypes' => '', 'channel' => '', 'bookingChannelsWithAutoMapping' => '', 'RoomOccupancy' => '', 'HotelFilters' => '', 'RoomTypeFilters' => '');

    function __construct($aInput, $aRoomOccupancy, $aRoomTypeFilters = null, $aHotelFilters = null) {
        $this->aInput = $aInput;
        $this->aRoomOccupancy = self::obj2Array($aRoomOccupancy);
        $this->aRoomTypeFilters = $aRoomTypeFilters;
        $this->aHotelFilters = $aHotelFilters;
    }

    Public function insertVar() {
        $aInputArray = get_object_vars($this->aInput);
        $aRoomOccupancyArray = $this->aRoomOccupancy;
        if (isset($this->aRoomTypeFilters)) {
            $aRoomTypeFiltersArray = get_object_vars($this->aRoomTypeFilters);
        }
        if (isset($this->aHotelFilters)) {
            $aHotelFiltersArray = get_object_vars($this->aHotelFilters);
        }
        foreach ($aInputArray as $key => $value) {
            if (isset($aInputArray[$key])) {
                self::$arrayConverted[$key] = $value;
            }
        }
        self::$arrayConverted['RoomOccupancy'] = $aRoomOccupancyArray;
        self::$arrayConverted['HotelFilters'] = $aHotelFiltersArray;
        self::$arrayConverted['RoomTypeFilters'] = $aRoomTypeFiltersArray;
    }

    Public static function obj2Array(&$obj) {
        foreach ($obj as $key => $value) {
            if (is_object($value)) {
                $arrayin[$key] = get_object_vars($value);
            } else {
                $arrayin[$key] = $value;
            }
        }
        return $arrayin;
    }

    Public function convertToBool() {
        //REPLACE BOOLEANS WITH y AND N
        foreach (self::$arrayConverted as $key => $value) {
            if (is_array($value)) {
                foreach ($value as $keyin => $valuein) {
                    if (is_array($valuein)) {
                        foreach ($valuein as $keyinin => $valueinin) {
                            $val = $valueinin;
                            if (gettype($val) == 'boolean') {
                                if ($val) {
                                    $val = 'Y';
                                } else {
                                    $val = 'N';
                                }
                                self::$arrayConverted[$key][$keyin][$keyinin] = $val;
                            }
                        }
                    } else {
                        $val = $valuein;
                        if (gettype($val) == 'boolean') {
                            if ($val) {
                                $val = 'Y';
                            } else {
                                $val = 'N';
                            }
                            self::$arrayConverted[$key][$keyin] = $val;
                        }
                    }
                }
            } else {
                $val = $value;
                if (gettype($val) == 'boolean') {
                    if ($val) {
                        $val = 'Y';
                    } else {
                        $val = 'N';
                    }
                    self::$arrayConverted[$key] = $val;
                }
            }
        }
        return true;
    }

    Public function returnArray() {
        return self::$arrayConverted;
    }

    //INCLUDE IN GLUES THE SIGN TO SEPARATE VALUES by EXAMPLE array("|",",","~","#")
    public static function convertRequestArrayToString(array $glues, array &$array) {
        $out = "";
        $g = array_shift($glues);
        $c = count($array);
        $i = 0;
        foreach ($array as $val) {
            if (is_array($val)) {
                $out .= self::convertRequestArrayToString($glues, $val);
            } else {
                $out .= (string) $val;
            }
            $i++;
            if ($i < $c) {
                $out .= $g;
            }
        }
        unset($i, $c, $g, $val, $array, $glues);
        return $out;
    }

}

/*
 * Class to management all the TCP communication request and response
 */

class ConnectorTCP {

    Private $string;
    Private $server;
    Private $port;
    Public static $answer;

    function __construct($string, $server, $port) {
        $this->string = $string;
        $this->server = $server;
        $this->port = $port;
    }

    Public function requestTCP() {

        set_time_limit(0);
        $debug = false;
        $server = $this->server;
        $port = $this->port;
        $seconds = 3;
        $var = $this->string;
        $message = "PSFILTER |$var\r\n";
        $buffer = '';
        //$message="PSFILTER |164|prod|1|Y|14,24,34,44,54,64|||||1~5#5#10~N~N,2~2#3#6~N~N||\r\n";
        //////////////////////////////
        if (!($sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP))) {
            if ($debug) {
                $errorcode = socket_last_error();
                $errormsg = socket_strerror($errorcode);
                die("Couldn't create socket: [$errorcode] $errormsg \n");
            }
            return false;
        }
        if ($debug) {
            echo "Socket created \n";
        }
        //Connect socket to remote server
        socket_set_option($sock, SOL_SOCKET, SO_SNDTIMEO, array('sec' => 5, 'usec' => 0));
        if (!socket_connect($sock, $server, $port)) {
            if ($debug) {
                $errorcode = socket_last_error();
                $errormsg = socket_strerror($errorcode);
                die("Could not connect: [$errorcode] $errormsg \n");
            }
            return false;
        }
        if ($debug) {
            echo "Connection established \n";
        }
        //Send the message to the server
        if (!socket_send($sock, $message, strlen($message), 0)) {
            if ($debug) {
                $errorcode = socket_last_error();
                $errormsg = socket_strerror($errorcode);
                die("Could not send data: [$errorcode] $errormsg \n");
            }
            return false;
        } else {
            if ($debug) {
                echo "Message send successfully \n";
            }
        }
        //Receive an answer
        socket_set_option($sock, SOL_SOCKET, SO_RCVTIMEO, array('sec' => 5, 'usec' => 0));
        while ($buf = socket_read($sock, 2048000, PHP_NORMAL_READ)) {
            if ($debug) {
                echo "Answer from server: $buffer";
            }
            break;
        }
        //IF need the string "QUIT" to close the socket, enable this and disable the previous one.
        /*
          $message = "QUIT\r\n";
          if( !socket_send ( $sock , $message , strlen($message) , 0))
          {
          $errorcode = socket_last_error();
          $errormsg = socket_strerror($errorcode);

          die("Could not send data: [$errorcode] $errormsg \n");
          } else {
          if ($debug) echo "Message QUIT send successfully \n";
          }
         */
        socket_close($sock);
        unset($message, $server, $port, $seconds, $debug, $sock, $errorcode, $errormsg);
        self::$answer = $buf;
        return true;
    }

    public function returnAnswerTCP() {
        return self::$answer;
    }

}

/*
 * Create an Array and modify the type of attributes
 */

class fillArrayValues {

    Public static $answerStatic = array();

    Public function distributeValues($param) {
        $arrayAnswer = explode("|||", $param);
        $array_need = array();
        //Remove OK String
        //unset($arrayAnswer[0]);
        $arrayAnswerSplice = array_splice($arrayAnswer, 1);
        foreach ($arrayAnswerSplice as $array_values) {
            if ($array_values) {
                $folders = explode(",", $array_values);
                $array_need[$folders[0]][$folders[1]][$folders[5]]['cityCode'] = $folders[2];
                $array_need[$folders[0]][$folders[1]][$folders[5]]['roomData'][] = $folders[4];
                if (isset($folders[6])) {
                    if ($folders[6] != ''){
                    $array_need[$folders[0]][$folders[1]][$folders[5]]['roomData'][] = trim($folders[6]);
                    }
                }
                $array_need[$folders[0]][$folders[1]][$folders[5]]['hotelCodeOriginal'] = $folders[3];
            }
        }
        unset($folders, $arrayAnswer, $array_values,$arrayAnswerSplice);
        self::$answerStatic = $array_need;
        return true;
    }

}
