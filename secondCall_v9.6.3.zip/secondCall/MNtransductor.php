<?php

//CLASS FROM PARTNER INCLUDE ALL THE OBJETS THAT WE NEED.
//MNtransductor Class, include all the class that make the hard work.

/*
 * Use example;
 * We only need call this function to start the process.
 * And we will receive the answer in array format.
 */

/*
 * MNtransductorClass.php, include all the class that make the hard work. 
 */
require 'MNtransductorClass.php';

error_reporting(E_ALL);
ini_set('display_errors','On');
ini_set('error_log','/logs/errors.log');

/*
 * This is a example of USE of the FUNCTION
 */

$requestNumber = 0;
$numberOfRequest = 1;
$err = 0;
$start = microtime(true);

while ($requestNumber < $numberOfRequest){
$run = new \Second\run;
$answerRequest = $run->managerSupplierRequest(new \Hotel\StaticData\StaticInput);


if ($answerRequest == false) {
    echo "Error: ";
    print_r($run->getError());
    echo "Error code: ";
    print_r($run->getErrorCode());
    echo "\n";
    echo "Received value: ";
    var_export($answerRequest);
    echo "\n\r";
    echo "##\n\r";
    
    $err++;
} else {
    echo "\n\r";
    var_export($answerRequest);
    echo "\n\r";
    echo "## ";
    echo "NUMERO DE HOTELES RECIBIDOS ";
    var_export(count($answerRequest));
    echo " ##\n\r";
}
$requestNumber++;

}

$time_elapsed_secs = microtime(true) - $start;
echo "REQUEST = " . $numberOfRequest;
echo "\r";
echo "ERRORS = " . $err;
echo "\r";
echo "TIME ELAPSED = " . $time_elapsed_secs;
echo "\n\r";


//
//$run = new \Second\run;
//$answerRequest = $run->managerSupplierRequest(new \Hotel\StaticData\StaticInput);
//if ($answerRequest == false) {
//    echo "Error ######################\r\n";
//} else {
//    var_export($answerRequest);
//}
//
////function managerSupplierRequest_2dn() {
////    $server = '127.0.0.1';
////    $port = 10003;
////    $aStaticInput = new \Hotel\StaticData\StaticInput();
////    $aReturnHotelStaticData = new Hotel\StaticData\ReturnHotelStaticData();
////    $aReturnRoomTypeStaticData = new Hotel\StaticData\ReturnRoomTypeStaticData();
////    $classCheck = new \Second\Check();
////    /*
////     * Check Mandatory and type attributes from all the objets needed.
////     */
////    if (!$classCheck->mandatoryTypeStaticInput($aStaticInput)) {
////        echo "error check input";
////        return false;
////    }
////    if (!$classCheck->mandatoryTypeReturnHotelStaticData($aReturnHotelStaticData)) {
////        echo "error check Hotel Static Data";
////        return false;
////    }
////    if (!$classCheck->mandatoryTypeReturnRoomTypeStaticData($aReturnRoomTypeStaticData)) {
////        echo "error check Room Type Static";
////        return false;
////    }
////    /*
////     * Create an Instance of CONSTRUCTOR and give all the objets needed it
////     */
////    $contructor = new \Second\Constructor($aStaticInput, $aReturnHotelStaticData, $aReturnRoomTypeStaticData);
////    /*
////     * Join all the attributes from all the objets in a simple array
////     */
////    $contructor->insertVar();
////    /*
////     * Convert all the Booleans values to "Y" or "N"
////     */
////    $contructor->convertToBool();
////    /*
////     * Create the string that need the DAEMON Server
////     */
////    //print_r($contructor->returnArray());
////    $string = $contructor->convertRequestArrayToString(array("|", ",", "~", "#"), $contructor->returnArray());
////    /*
////     * Create an Instance of ConnectorTCP and give the var for connection
////     */
////    $connector = new \Second\ConnectorTCP($string, $server, $port);
////    /*
////     * Send the String to the DAEMON Server
////     */
////    $connector->requestTCP();
////    /*
////     * Manage the answer and check Mandatory and type
////     */
////
////    if ($classCheck->answer($connector->returnAnswerTCP())) {
////        /*
////         * If we have answer and the mandatory value and type are correct
////         * we fill the array to answer
////         */
////        $mngAnswer = new \Second\fillStaticInputValues();
////        if ($mngAnswer->distributeValues($connector->returnAnswerTCP())) {
////            //print_r($mngAnswer::$answerStatic);
////        }
////    } else {
////        echo "error check in answer";
////        return false;
////    }
////    /*
////     * Answer in a return or send FALSE in error.
////     */
////    return $mngAnswer::$answerStatic;
////}
