<?php

namespace Hotel\PreSupplier;


class RoomTypeFilters {


    public $suite;
    public $roomAmenitie = array();
    public $roomId = array();
    public $roomName;

} 