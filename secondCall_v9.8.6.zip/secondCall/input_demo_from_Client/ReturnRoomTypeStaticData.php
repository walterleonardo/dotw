<?php


namespace Hotel\PreSupplier;


class ReturnRoomTypeStaticData {

public $twin = false; //NO MANDATORY BOOL
public $roomAmenities = false;
public $name = true;
public $roomInfo= false;

}