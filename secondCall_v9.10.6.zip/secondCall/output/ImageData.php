<?php
/**
 * Created by PhpStorm.
 * User: adi
 * Date: 1/13/2016
 * Time: 11:34 AM
 */

namespace Hotel\StaticData;


class ImageData
{

    public $thumb;
    public $alt;
    public $category;
    public $url;
    public $roomTypeId;

} 