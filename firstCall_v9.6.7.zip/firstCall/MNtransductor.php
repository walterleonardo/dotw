<?php
/*
 * Class to translate objest attributes in a string to request information from DAEMON Server.
 *  2016
 * 
 * Enterprise MULTINUCLEO.COM
 * Created by Walter Lopez Pascual
 * 
 * 
 * Use example;
 * To start the process we only need call this class "RUN" and the 
 * method "managerSupplierRequest" after to fill all the attributes into the objects.
 * And we will receive the answer in array format or False in error.
 * This function internaly call to the OBJESTs and their attributes that we need for the request.
 */
/*
 * MNtransductorClass.php, include all the class that make the hard work. 
 */
require 'MNtransductorClass.php';
/*
 * This is a example of USE of the FUNCTION
 */

$requestNumber = 0;
$numberOfRequest = 1;
$err = 0;
$start = microtime(true);

while ($requestNumber < $numberOfRequest){
$run = new \Firts\Run;
$run2 = new \Firts\Run;
$answerRequest = $run->managerSupplierRequest(new \Hotel\PreSupplier\Input);
if ($answerRequest == false) {
    echo "Error: ";
    print_r($run->getError());
    echo "Error code: ";
    print_r($run->getErrorCode());
    echo "\n";
    $err++;
} else {
    var_export($answerRequest);
}
$requestNumber++;

}

$time_elapsed_secs = microtime(true) - $start;
echo "REQUEST = " . $numberOfRequest;
echo "\r";
echo "ERRORS = " . $err;
echo "\r";
echo "TIME ELAPSED = " . $time_elapsed_secs;
echo "\n\r";