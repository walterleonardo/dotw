<?php

namespace Hotel\StaticData;

class StaticInput {
//941895 //139534
    public $hotelIds = array (
    30304 => 
    array (
 0 => 57854
                    ,1 => 945306
                    ,2 => 5186945
                    ,3 => 5186955
                    ,4 => 5186965
                    ,5 => 5186975
                    ,6 => 5186985
                    ,7 => 5186995
                    ,8 => 5187005
                    ,9 => 5188175
                    ,10 => 5188185
                    ,11 => 5188195
                    ,12 => 5188215
                    ,13 => 5211055
                    ,14 => 5975235
                    ,15 => 6047598
                    ,16 => 6047648
                    ,17 => 7227868
                    ,18 => 9362668
                    ,19 => 9362678
                    ,20 => 10966038
                    ,21 => 11741408
                    ,22 => 11741418
                    ,23 => 13044908
                    ,24 => 13044918
                    ,25 => 13044938
                    ,26 => 13044948
                    ,27 => 13044968
                    ,28 => 13044978
                    ,29 => 13045008
                    ,30 => 14569148
                    ,31 => 15344328
                    ,32 => 17711978
                    ,33 => 17711988
                    ,34 => 17712008
                    ,35 => 17712018
                    ,36 => 17712028
                    ,37 => 17712038
                    ,38 => 17712048
                    ,39 => 17712058
                    ,40 => 17712068
                    ,41 => 17712078
                    ,42 => 17712088
                    ,43 => 17712098
                    ,44 => 17813338
                    ,45 => 17813348
                    ,46 => 17813358
                    ,47 => 17813368
                    ,48 => 17813378
                    ,49 => 17813388
                    ,50 => 17813398
                    ,51 => 17813408
                    ,52 => 17813418
                    ,53 => 17813428
                    ,54 => 17813438
                    ,55 => 17813448
                    ,56 => 17813458
                    ,57 => 17813468
                    ,58 => 17813478
                    ,59 => 17813488
                    ,60 => 17813498
                    ,61 => 17813508
                    ,62 => 17813518
                    ,63 => 17813528
                    ,64 => 17813538
                    ,65 => 17813548
                    ,66 => 17813558
                    ,67 => 17813568
                    ,68 => 17813578
                    ,69 => 17813588
                    ,70 => 17813598
                    ,71 => 17813608
                    ,72 => 17813618
                    ,73 => 17813628
                    ,74 => 17813638
                    ,75 => 17813648
                    ,76 => 17813658
                    ,77 => 17813668
                    ,78 => 17813678
                    ,79 => 17813688
                    ,80 => 17813698
                    ,81 => 17813708
                    ,82 => 17813718
                    ,83 => 17813728
                    ,84 => 17813738
                    ,85 => 17813748
                    ,86 => 17813758
                    ,87 => 17813768
                    ,88 => 17813778
                    ,89 => 17813788
                    ,90 => 17813798
                    ,91 => 17813808
                    ,92 => 17813818
                    ,93 => 17813838
                    ,94 => 20504445
                    ,95 => 20504455
                    ,96 => 20504465
                    ,97 => 20504475
                    ,98 => 20504485
                    ,99 => 20504495
                    ,100 => 20504505
                    ,101 => 20504515
                    ,102 => 20504525
                    ,103 => 32054345
                    ,104 => 32054355
                    ,105 => 32054365
                    ,106 => 32054375
                    ,107 => 32054385
                    ,108 => 32054395
                    ,109 => 32054405
                    ,110 => 32054415
                    ,111 => 32054425
                    ,112 => 32054435
                    ,113 => 32396275
                    ,114 => 33105355
                    ,115 => 33105425
                    ,116 => 45325115
                    ,117 => 45325125
                    ,118 => 45367695
                    ,119 => 45367705
                    ,120 => 45367715
                    ,121 => 45367725
                    ,122 => 45367735
                    ,123 => 48225435
                    ,124 => 48225445
                    ,125 => 48225455
                    ,126 => 56210665
                    ,127 => 56210675
                    ,128 => 56210685
                    ,129 => 56210695
                    ,130 => 56210705
                    ,131 => 56210715
                    ,132 => 56210725
                    ,133 => 56210735
                    ,134 => 56210745
                    ,135 => 56210755
                    ,136 => 58011725
                    ,137 => 58011735
                    ,138 => 58011745
                    ,139 => 58011755
                    ,140 => 58011765
                    ,141 => 58011775
                    ,142 => 58011785
                    ,143 => 58011795
                    ,144 => 58011805
                    ,145 => 58011815
                    ,146 => 58011825
                    ,147 => 58011835
                    ,148 => 58011845
                    ,149 => 58011855
                    ,150 => 58011865
                    ,151 => 58011875
                    ,152 => 58997375
                    ,153 => 61558355
                    ,154 => 61558365
                    ,155 => 61558375
                    ,156 => 61558385
                    ,157 => 61558395
                    ,158 => 61558405
                    ,159 => 61558415
                    ,160 => 61558425
                    ,161 => 61558435
                    ,162 => 61558445
                    ,163 => 61558455
                    ,164 => 61558465
                    ,165 => 61558475
                    ,166 => 61558485
                    ,167 => 61558495
                    ,168 => 61558505
                    ,169 => 61558515
                    ,170 => 61558525
                    ,171 => 61558535
                    ,172 => 66666075
                    ,173 => 66666085
                    ,174 => 66666095
                    ,175 => 66666105
                    ,176 => 66666115
                    ,177 => 66666125
                    ,178 => 66666135
                    ,179 => 66666145
                    ,180 => 67048355
                    ,181 => 67048365
                    ,182 => 67048375
                    ,183 => 67048385
                    ,184 => 67048395
                    ,185 => 67048405
                    ,186 => 67048415
                    ,187 => 67048425
                    ,188 => 74883975
                    ,189 => 74883985
    ),
    );
    public $LanguageId = 1;
    //MANDATORY ARRAY
    /**
     * @var ReturnHotelStaticData;
     */
    public $ReturnHotelStaticData = array();

    /**
     * @var ReturnRoomTypeStaticData;
     */
    public $ReturnRoomTypeStaticData = array();

    /**
     * @var ReturnRateData;
     */
    public $ReturnRateData = array();

    function __construct() {
        $this->ReturnHotelStaticData = new ReturnHotelStaticData();
        $this->ReturnRoomTypeStaticData = new ReturnRoomTypeStaticData();
        $this->ReturnRateData = new ReturnRateData();
    }

}

class ReturnHotelStaticData {
    public $description1 = false; //NO MANDATORY BOOL
    public $description2 = false;
    public $geoPoint = false;
    public $ratingDescription = false;
    public $images = false;
    public $direct = false;
    public $hotelPreference = false;
    public $builtYear = false;
    public $renovationYear = false;
    public $floors = false;
    public $noOfRooms = false;
    public $luxury = false;
    public $address = false;
    public $zipCode = false;
    public $location = false;
    public $locationId = false;
    public $location1 = false;
    public $location2 = false;
    public $location3 = false;
    public $stateName = false;
    public $stateCode = false;
    public $countryName = true;
    public $regionName = false;
    public $regionCode = false;
    public $amenitie = false;
    public $leisure = false;
    public $business = false;
    public $transportation = false;
    public $hotelPhone = false;
    public $hotelCheckIn = false;
    public $hotelCheckOut = false;
    public $minAge = false;
    public $rating = false;
    public $fireSafety = false;
    public $chain = false;
    public $lastUpdated = false;
    public $transferMandatory = false;
    public $tariffNotes = false;
    public $chainName = false;
    public $hotelProperty = false;
    public $fullAddress = false;//Future develop
    public $exclusive = false; 
    public $attraction = false;//Future develop
    public $areaCode = false;//Future develop
    public $areaName = false;//Future develop
    public $geoLocations = false;//Future develop
}

class ReturnRoomTypeStaticData {
    public $roomAmenities = false;
    public $name = true;
    public $twin = false; //NO MANDATORY BOOL
    public $roomInfo = false;
    public $specials = false;
    public $roomImages = false;
    public $roomCategory = false; //new attribute
}

class ReturnRateData {
    public $occupancy = true;
    public $status = true;
    public $rateType = true;
    public $paymentMode = true;
    public $allowsExtraMeals = true;
    public $allowsSpecialRequests = true;
    public $allowsBeddingPreference = true;
    public $allowsSpecials = true;
    public $passengerNamesRequiredForBooking = true;
    public $allocationDetails = true;
    public $minStay = true;
    public $dateApplyMinStay = true;
    public $cancellationRules = true;
    public $withinCancellationDeadline = true;
    public $tariffNotes = true;
    public $isBookable = true;
    public $onRequest = true;
    public $total = true;
    public $dates = true;
    public $freeStay = true;
    public $discount = true; 
    public $dayOnRequest = true;
    public $including = true;
    public $dailyLeftToSell = true;
    public $dailyMinStay = true;
    public $leftToSell = true; 
    public $specials = true;
}
