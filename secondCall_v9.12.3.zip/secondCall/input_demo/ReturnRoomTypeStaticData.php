<?php


namespace Hotel\PreSupplier;


class ReturnRoomTypeStaticData {

public $twin = NULL; //NO MANDATORY BOOL
public $roomAmenities = NULL;
public $name = NULL;
public $roomInfo= NULL;

}