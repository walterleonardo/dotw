<?php


namespace Hotel\StaticData;


class ReturnRoomTypeStaticData
{

    public $twin;
    public $roomAmenities;
    public $name;
    public $roomInfo;

} 