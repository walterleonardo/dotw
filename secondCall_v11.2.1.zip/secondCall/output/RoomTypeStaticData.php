<?php
/**
 * Created by PhpStorm.
 * User: walterleonardo@gmail.com
 * Date: 1/12/2016
 * Time: 6:33 PM
 */

namespace Hotel\StaticData;


class RoomTypeStaticData
{
    public $twin;
    public $roomAmenities;
    public $name;
    public $supplierRoomName;
    public $roomInfo;
    public $roomCategory;
} 