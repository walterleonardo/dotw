<?php
/**
 * Created by PhpStorm.
 * User: adi
 * Date: 1/12/2016
 * Time: 6:33 PM
 */

namespace Hotel\PreSupplier;


class RoomTypeStaticData
{

    public $twin;
    public $roomAmenities;
    public $name;
    public $roomInfo;
} 