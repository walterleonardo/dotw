<?php

namespace Hotel\PreSupplier;


class StaticInput
{

    public $hotelIds = array(
    0 => 993975,
    1 => 30314,
    2 => 30304,
  ); //MANDATORY ARRAY
    /**
     * @var ReturnHotelStaticData;
     */
    public $ReturnHotelStaticData = array();


    /**
     * @var ReturnRoomTypeStaticData;
     */
    public $ReturnRoomTypeStaticData = array();

    function __construct() {
$this->ReturnHotelStaticData = new ReturnHotelStaticData();
$this->ReturnRoomTypeStaticData = new ReturnRoomTypeStaticData();
}

}

class ReturnHotelStaticData {

public $description1 = true; //NO MANDATORY BOOL
public $description2 = false;
public $geoPoints = false;
public $ratingDescription = true;
public $images = true;
public $direct = false;
public $hotelPreference = false;
public $builtYear= false;
public $renovationYear= false;
public $floors= false;
public $noOfRooms= false;
public $luxury= true;
public $address= false;
public $zipCode= false;
public $location= true;
public $locationId= false;
public $location1= false;
public $location2= false;
public $location3= false;
public $stateName= false;
public $stateCode= false;
public $countryName= false;
public $regionName= false;
public $regionCode= false;
public $attraction= false;
public $amenitie= false;
public $leisure= false;
public $business= false;
public $transportation= false;
public $hotelPhone= true;
public $hotelCheckIn= false;
public $hotelCheckOut= false;
public $minAge= false;
public $rating= false;
public $fireSafety= false;
public $geoPoint= true;
public $chain= false;
public $lastUpdated= false;

}

class ReturnRoomTypeStaticData {

public $twin = false; //NO MANDATORY BOOL
public $roomAmenities = false;
public $name = false;
public $roomInfo= false;

}