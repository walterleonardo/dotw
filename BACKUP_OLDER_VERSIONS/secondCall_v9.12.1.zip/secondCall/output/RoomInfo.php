<?php
/**
 * Created by PhpStorm.
 * User: adi
 * Date: 1/13/2016
 * Time: 11:35 AM
 */

namespace Hotel\StaticData;


class RoomInfo {

    public $maxOccupancy;
    public $maxAdultWithChildren;
    public $minChildAge;
    public $maxChildAge;
    public $maxAdult;
    public $maxExtraBed;
    public $maxChildren;
    public $children;

} 