<?php
/**
 * Created by PhpStorm.
 * User: walterleonardo@gmail.com
 * Date: 1/12/2016
 * Time: 6:34 PM
 */

namespace Hotel\StaticData;


class TransportationData
{
    public $Type;
    public $Name;
    public $Dist;
    public $DistanceUnit;
    public $DistTime;
    public $Directions;

} 