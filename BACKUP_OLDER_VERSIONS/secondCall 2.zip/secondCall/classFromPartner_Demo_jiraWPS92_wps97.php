<?php

namespace Hotel\StaticData;

class StaticInput {
//941895 //139534
    public $hotelIds = array (
    30304 => 
    array (
0 => 3701765
                    ,1 => 3701775
                    ,2 => 3701785
                    ,3 => 3701795
                    ,4 => 6044355
                    ,5 => 6129095
                    ,6 => 6129105
                    ,7 => 6129115
                    ,8 => 7398808
                    ,9 => 7398828
                    ,10 => 7398848
                    ,11 => 7398868
                    ,12 => 9319208
                    ,13 => 9319218
                    ,14 => 11768758
                    ,15 => 11818848
                    ,16 => 11818858
                    ,17 => 12260368
                    ,18 => 12260398
                    ,19 => 12260588
                    ,20 => 12260608
                    ,21 => 12260618
                    ,22 => 12260638
                    ,23 => 12260648
                    ,24 => 12260658
                    ,25 => 12260918
                    ,26 => 20564895
                    ,27 => 20565075
                    ,28 => 20565085
                    ,29 => 20565095
                    ,30 => 20565105
                    ,31 => 20565115
                    ,32 => 20565125
                    ,33 => 20565135
                    ,34 => 20565145
                    ,35 => 20565155
                    ,36 => 20565165
                    ,37 => 20565175
                    ,38 => 20565185
                    ,39 => 20565195
                    ,40 => 20565205
                    ,41 => 20565215
                    ,42 => 20565225
                    ,43 => 20565235
                    ,44 => 20565245
                    ,45 => 20565255
                    ,46 => 20565265
                    ,47 => 20565275
                    ,48 => 20565285
                    ,49 => 20565295
                    ,50 => 20565305
                    ,51 => 20565315
                    ,52 => 20565325
                    ,53 => 20565335
                    ,54 => 20565345
                    ,55 => 20565355
                    ,56 => 20565365
                    ,57 => 20565375
                    ,58 => 20565385
                    ,59 => 20565395
                    ,60 => 20565405
                    ,61 => 20565415
                    ,62 => 20565425
                    ,63 => 20565435
                    ,64 => 20565445
                    ,65 => 20565455
                    ,66 => 22983575
                    ,67 => 22983585
                    ,68 => 22983595
                    ,69 => 22983605
                    ,70 => 22983615
                    ,71 => 22983625
                    ,72 => 22983635
                    ,73 => 22983645
                    ,74 => 22983655
                    ,75 => 22983665
                    ,76 => 22983675
                    ,77 => 22983685
                    ,78 => 22983695
                    ,79 => 22983705
                    ,80 => 22983715
                    ,81 => 22983725
                    ,82 => 22983735
                    ,83 => 22983745
                    ,84 => 22983755
                    ,85 => 22983765
                    ,86 => 22983775
                    ,87 => 22983805
                    ,88 => 22983815
                    ,89 => 22983825
                    ,90 => 22983835
                    ,91 => 22983845
                    ,92 => 22983855
                    ,93 => 22983865
                    ,94 => 22983875
                    ,95 => 22983885
                    ,96 => 22983895
                    ,97 => 22983905
                    ,98 => 22983915
                    ,99 => 22983925
                    ,100 => 22983935
                    ,101 => 30308135
                    ,102 => 30308145
                    ,103 => 30308155
                    ,104 => 30308165
                    ,105 => 30308175
                    ,106 => 30308585
                    ,107 => 30308645
                    ,108 => 30308685
                    ,109 => 30308695
                    ,110 => 30308725
                    ,111 => 30308745
                    ,112 => 30308795
                    ,113 => 30308905
                    ,114 => 30308925
                    ,115 => 30308935
                    ,116 => 30308965
                    ,117 => 30308985
                    ,118 => 30309005
                    ,119 => 30309145
                    ,120 => 30309165
                    ,121 => 30309195
                    ,122 => 30309215
                    ,123 => 30309235
                    ,124 => 30309265
                    ,125 => 30309425
                    ,126 => 30309435
                    ,127 => 30309445
                    ,128 => 30309455
                    ,129 => 30309465
                    ,130 => 30309515
                    ,131 => 39893865
                    ,132 => 39949145
                    ,133 => 39949155
                    ,134 => 42114835
                    ,135 => 43263895
                    ,136 => 43528405
                    ,137 => 43575975
                    ,138 => 44090295
                    ,139 => 46760705
                    ,140 => 46762285
                    ,141 => 46762985
                    ,142 => 48380005
                    ,143 => 48381145
                    ,144 => 48381525
                    ,145 => 49252385
                    ,146 => 55858515
                    ,147 => 57826635
                    ,148 => 57826645
                    ,149 => 57826655
                    ,150 => 57826665
                    ,151 => 57826675
                    ,152 => 57826685
                    ,153 => 57826695
                    ,154 => 57826705
                    ,155 => 57826715
                    ,156 => 57826725
                    ,157 => 57826735
                    ,158 => 57826745
                    ,159 => 57826755
                    ,160 => 57826765
                    ,161 => 57826775
                    ,162 => 57826785
                    ,163 => 57826795
                    ,164 => 57826805
                    ,165 => 57826815
                    ,166 => 58615065
                    ,167 => 58786035
                    ,168 => 60218085
                    ,169 => 60218095
                    ,170 => 60879265
                    ,171 => 60879275
                    ,172 => 60879285
                    ,173 => 60879295
                    ,174 => 60879305
                    ,175 => 60879315
                    ,176 => 60879325
                    ,177 => 60879335
                    ,178 => 60879345
                    ,179 => 60879355
                    ,180 => 60879365
                    ,181 => 60879375
                    ,182 => 60879385
                    ,183 => 60879395
                    ,184 => 60879405
                    ,185 => 64844935
                    ,186 => 64844945
                    ,187 => 64996235
                    ,188 => 65005235
                    ,189 => 67030845
                    ,190 => 67434455
                    ,191 => 67452855
                    ,192 => 67466195
                    ,193 => 68457015
                    ,194 => 69223235
                    ,195 => 69558285
                    ,196 => 72477155
                    ,197 => 74389015
                    ,198 => 74502495
    ),
    );
    public $LanguageId = 16;
    //MANDATORY ARRAY
    /**
     * @var ReturnHotelStaticData;
     */
    public $ReturnHotelStaticData = array();

    /**
     * @var ReturnRoomTypeStaticData;
     */
    public $ReturnRoomTypeStaticData = array();

    /**
     * @var ReturnRateData;
     */
    public $ReturnRateData = array();

    function __construct() {
        $this->ReturnHotelStaticData = new ReturnHotelStaticData();
        $this->ReturnRoomTypeStaticData = new ReturnRoomTypeStaticData();
        $this->ReturnRateData = new ReturnRateData();
    }

}

class ReturnHotelStaticData {
    public $description1 = false; //NO MANDATORY BOOL
    public $description2 = false;
    public $geoPoint = false;
    public $ratingDescription = false;
    public $images = false;
    public $direct = false;
    public $hotelPreference = false;
    public $builtYear = false;
    public $renovationYear = false;
    public $floors = false;
    public $noOfRooms = false;
    public $luxury = false;
    public $address = false;
    public $zipCode = false;
    public $location = false;
    public $locationId = false;
    public $location1 = false;
    public $location2 = false;
    public $location3 = false;
    public $stateName = false;
    public $stateCode = false;
    public $countryName = true;
    public $regionName = false;
    public $regionCode = false;
    public $amenitie = false;
    public $leisure = false;
    public $business = false;
    public $transportation = false;
    public $hotelPhone = false;
    public $hotelCheckIn = false;
    public $hotelCheckOut = false;
    public $minAge = false;
    public $rating = false;
    public $fireSafety = false;
    public $chain = false;
    public $lastUpdated = false;
    public $transferMandatory = false;
    public $tariffNotes = false;
    public $chainName = false;
    public $hotelProperty = false;
    public $fullAddress = false;//Future develop
    public $exclusive = false; 
    public $attraction = false;//Future develop
    public $areaCode = false;//Future develop
    public $areaName = false;//Future develop
    public $geoLocations = false;//Future develop
}

class ReturnRoomTypeStaticData {
    public $roomAmenities = true;
    public $name = true;
    public $twin = true; //NO MANDATORY BOOL
    public $roomInfo = true;
    public $specials = true;
    public $roomImages = true;
    public $roomCategory = true; //new attribute
}

class ReturnRateData {
    public $occupancy = true;
    public $status = true;
    public $rateType = true;
    public $paymentMode = true;
    public $allowsExtraMeals = true;
    public $allowsSpecialRequests = true;
    public $allowsBeddingPreference = true;
    public $allowsSpecials = true;
    public $passengerNamesRequiredForBooking = true;
    public $allocationDetails = true;
    public $minStay = true;
    public $dateApplyMinStay = true;
    public $cancellationRules = true;
    public $withinCancellationDeadline = true;
    public $tariffNotes = true;
    public $isBookable = true;
    public $onRequest = true;
    public $total = true;
    public $dates = true;
    public $freeStay = true;
    public $discount = true; 
    public $dayOnRequest = true;
    public $including = true;
    public $dailyLeftToSell = true;
    public $dailyMinStay = true;
    public $leftToSell = true; 
    public $specials = true;
}
