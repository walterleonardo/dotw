<?php


namespace Hotel\PreSupplier;


class ReturnRoomTypeStaticData
{

    public $twin;
    public $roomAmenities;
    public $name;
    public $roomInfo;

} 