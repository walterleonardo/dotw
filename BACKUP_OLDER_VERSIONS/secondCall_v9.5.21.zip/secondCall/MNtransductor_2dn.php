<?php

//CLASS FROM PARTNER INCLUDE ALL THE OBJETS THAT WE NEED.
//require 'classFromPartner_2dn.php';
//MNtransductor Class, include all the class that make the hard work.
require 'MNtransductorClass_2dn.php';

/*
 * Use example;
 * We only need call this function to start the process.
 * And we will receive the answer in array format.
 */
$run = new \Second\run;
$answerRequest = $run->managerSupplierRequest(new \Hotel\PreSupplier\StaticInput);
if ($answerRequest == false) {
    echo "Error ######################\r\n";
} else {
    var_export($answerRequest);
}

//function managerSupplierRequest_2dn() {
//    $server = '127.0.0.1';
//    $port = 10003;
//    $aStaticInput = new \Hotel\PreSupplier\StaticInput();
//    $aReturnHotelStaticData = new Hotel\PreSupplier\ReturnHotelStaticData();
//    $aReturnRoomTypeStaticData = new Hotel\PreSupplier\ReturnRoomTypeStaticData();
//    $classCheck = new \Second\Check();
//    /*
//     * Check Mandatory and type attributes from all the objets needed.
//     */
//    if (!$classCheck->mandatoryTypeStaticInput($aStaticInput)) {
//        echo "error check input";
//        return false;
//    }
//    if (!$classCheck->mandatoryTypeReturnHotelStaticData($aReturnHotelStaticData)) {
//        echo "error check Hotel Static Data";
//        return false;
//    }
//    if (!$classCheck->mandatoryTypeReturnRoomTypeStaticData($aReturnRoomTypeStaticData)) {
//        echo "error check Room Type Static";
//        return false;
//    }
//    /*
//     * Create an Instance of CONSTRUCTOR and give all the objets needed it
//     */
//    $contructor = new \Second\Constructor($aStaticInput, $aReturnHotelStaticData, $aReturnRoomTypeStaticData);
//    /*
//     * Join all the attributes from all the objets in a simple array
//     */
//    $contructor->insertVar();
//    /*
//     * Convert all the Booleans values to "Y" or "N"
//     */
//    $contructor->convertToBool();
//    /*
//     * Create the string that need the DAEMON Server
//     */
//    //print_r($contructor->returnArray());
//    $string = $contructor->convertRequestArrayToString(array("|", ",", "~", "#"), $contructor->returnArray());
//    /*
//     * Create an Instance of ConnectorTCP and give the var for connection
//     */
//    $connector = new \Second\ConnectorTCP($string, $server, $port);
//    /*
//     * Send the String to the DAEMON Server
//     */
//    $connector->requestTCP();
//    /*
//     * Manage the answer and check Mandatory and type
//     */
//
//    if ($classCheck->answer($connector->returnAnswerTCP())) {
//        /*
//         * If we have answer and the mandatory value and type are correct
//         * we fill the array to answer
//         */
//        $mngAnswer = new \Second\fillStaticInputValues();
//        if ($mngAnswer->distributeValues($connector->returnAnswerTCP())) {
//            //print_r($mngAnswer::$answerStatic);
//        }
//    } else {
//        echo "error check in answer";
//        return false;
//    }
//    /*
//     * Answer in a return or send FALSE in error.
//     */
//    return $mngAnswer::$answerStatic;
//}
