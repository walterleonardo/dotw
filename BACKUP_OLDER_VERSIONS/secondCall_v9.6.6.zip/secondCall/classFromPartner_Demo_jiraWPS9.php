<?php

namespace Hotel\StaticData;

class StaticInput {

    public $hotelIds = array(
        0 => 60694,
      1 => 60704,
      2 => 60714,
      3 => 60724,
      4 => 60734,
      5 => 60744,
      6 => 224889,
      7 => 1251755,
      8 => 1251765,
      9 => 1251775,
      10 => 1251785,
      11 => 1251795,
      12 => 1251805,
      13 => 1251815,
      14 => 2307285,
      15 => 5169345,
      16 => 5370455,
      17 => 6564025,
      18 => 6564035,
      19 => 6564045,
      20 => 7687438,
      21 => 7687458,
      22 => 7687478,
      23 => 7687498,
      24 => 7688638,
      25 => 7692168,
      26 => 7706438,
      27 => 7706458,
      28 => 7706488,
      29 => 9242698,
      30 => 9242708,
      31 => 9242718,
      32 => 9501088,
      33 => 11525958,
      34 => 17739848,
      35 => 17739858,
      36 => 17739868,
      37 => 19565755,
      38 => 19565765,
      39 => 19565775,
      40 => 19565785,
      41 => 19565795,
      42 => 19565805,
      43 => 19565815,
      44 => 19565825,
      45 => 19565835,
      46 => 19565845,
      47 => 19565855,
      48 => 19565865,
      49 => 19565875,
      50 => 19565885,
      51 => 19565895,
      52 => 19565905,
      53 => 19565915,
      54 => 19565925,
      55 => 20501095,
      56 => 20501105,
      57 => 20501115,
      58 => 20501125,
      59 => 20501135,
      60 => 20501145,
      61 => 20501155,
      62 => 20501165,
      63 => 20501175,
    );
    public $LanguageId = 1;
    //MANDATORY ARRAY
    /**
     * @var ReturnHotelStaticData;
     */
    public $ReturnHotelStaticData = array();

    /**
     * @var ReturnRoomTypeStaticData;
     */
    public $ReturnRoomTypeStaticData = array();

    /**
     * @var ReturnRateData;
     */
    public $ReturnRateData = array();
    
    function __construct() {
        $this->ReturnHotelStaticData = new ReturnHotelStaticData();
        $this->ReturnRoomTypeStaticData = new ReturnRoomTypeStaticData();
        $this->ReturnRateData = new ReturnRateData();
    }

}

class ReturnHotelStaticData {

    public $description1 = true; //NO MANDATORY BOOL
    public $description2 = true;
    public $geoPoints = true;
    public $ratingDescription = true;
    public $images = true;
    public $direct = true;
    public $hotelPreference = true;
    public $builtYear = true;
    public $renovationYear = true;
    public $floors = true;
    public $noOfRooms = true;
    public $luxury = true;
    public $address = true;
    public $zipCode = true;
    public $location = true;
    public $locationId = true;
    public $location1 = true;
    public $location2 = true;
    public $location3 = true;
    public $stateName = true;
    public $stateCode = true;
    public $countryName = true;
    public $regionName = true;
    public $regionCode = true;
    public $attraction = true;
    public $amenitie = true;
    public $leisure = true;
    public $business = true;
    public $transportation = true;
    public $hotelPhone = true;
    public $hotelCheckIn = true;
    public $hotelCheckOut = true;
    public $minAge = true;
    public $rating = true;
    public $fireSafety = true;
    public $geoPoint = true;
    public $chain = true;
    public $lastUpdated = true;

}

class ReturnRoomTypeStaticData {

    public $twin = true; //NO MANDATORY BOOL
    public $roomAmenities = true;
    public $name = true;
    public $roomInfo = true;

}

class ReturnRateData {
    public $status = true;
    public $rateType = true;
    public $allowsExtraMeals = true;
    public $allowsSpecialRequests = true;
    public $allowsBeddingPreference = true;
    public $passengerNamesRequiredForBooking = true;
    public $allocationDetails = true;
    public $cancellationRules = true;
    public $minStay = true;
    public $withinCancellationDeadline = true;
    public $isBookable = true;
    public $onRequest = true;
    public $total = true;
    public $dates = true;
    public $specials = true;
    public $tariffNotes = true;
    public $dayOnRequest = true;
    public $including = true;
    public $leftToSellDaily = true;
    public $dailyMinStay = true;
    public $freeStay = true;
}
