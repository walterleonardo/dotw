<?php

namespace Second;

require 'output/HotelStaticData.php';
require 'output/ImageData.php';
require 'output/RoomTypeStaticData.php';
require 'output/TransportationData.php';
require 'output/RoomInfo.php';


//require 'input/StaticInput.php';
//require 'input/ReturnHotelStaticData.php';
//require 'input/ReturnRoomTypeStaticData.php';
//require 'input_demo/StaticInput.php';
//require 'input_demo/ReturnHotelStaticData.php';
//require 'input_demo/ReturnRoomTypeStaticData.php';
require 'input_demo_from_Client/StaticInput.php';
require 'input_demo_from_Client/ReturnHotelStaticData.php';
require 'input_demo_from_Client/ReturnRoomTypeStaticData.php';

/*
 * Class to translate objest attributes in a string to request information from DAEMON Server.
 * January 2016
 * 
 * Enterprise MULTINUCLEO.COM
 * Created by Walter Lopez Pascual
 */
/*
 * CLASS FROM PARTNER INCLUDE ALL THE OBJETS THAT WE NEED.
 * In this case you need change this require by the files with your objets attributes.
 * You can use the differents source objets files for differents requests (by PARIS, DUBAI or DEMO)
 */

class run {

    function managerSupplierRequest(\Hotel\PreSupplier\StaticInput $inputObj) {
        $server = '127.0.0.1'; //DAEMON SERVER IP or DOMAIN
        $port = 10003; //DAEMON SERVER PORT
        $aStaticInput = $inputObj;
        $aReturnHotelStaticData = $inputObj->ReturnHotelStaticData;
        $aReturnRoomTypeStaticData = $inputObj->ReturnRoomTypeStaticData;

        $classCheck = new \Second\Check();
        /*
         * Check Mandatory and type attributes from all the objets needed.
         */
        if (!$classCheck->mandatoryTypeStaticInput($aStaticInput)) {
            echo "error check input";
            return false;
        }
        if (!$classCheck->mandatoryTypeReturnHotelStaticData($aReturnHotelStaticData)) {
            echo "error check Hotel Static Data";
            return false;
        }
        if (isset($aReturnRoomTypeStaticData)) {
            if (!$classCheck->mandatoryTypeReturnRoomTypeStaticData($aReturnRoomTypeStaticData)) {
                echo "error check Room Type Static";
                return false;
            }
        }
        /*
         * Create an Instance of CONSTRUCTOR and give all the objets needed it
         */
        //var_export($aStaticInput);
        $contructor = new \Second\Constructor($aStaticInput, $aReturnHotelStaticData, $aReturnRoomTypeStaticData);
        /*
         * Join all the attributes from all the objets in a simple array
         */
        $contructor->insertVar();
        /*
         * Convert all the Booleans values to "Y" or "N"
         */
        $contructor->convertToBool();
        /*
         * Create the string that need the DAEMON Server
         */
        //var_export($contructor->returnArray());
        $string = $contructor->convertRequestArrayToString(array("|", ",", "~", "#"), $contructor->returnArray());
        /*
         * Create an Instance of ConnectorTCP and give the var for connection
         */
        $connector = new \Second\ConnectorTCP($string, $server, $port);
        /*
         * Send the String to the DAEMON Server
         */
//        print_r($string);
//        echo "\n\r";
        if (!$connector->requestTCP()) {
            return false;
        }
        /*
         * Manage the answer and check Mandatory and type
         */
        $answerFromTcp = $connector->returnAnswerTCP();
        if ($classCheck->answer($answerFromTcp)) {
            /*
             * If we have answer and the mandatory value and type are correct
             * we fill the array to answer
             */
//            echo "ANSWER\n\r";
//            print_r($answerFromTcp);
//            echo "####\n\r";
            $mngAnswer = new \Second\AnswerTreatment();
            if (!$mngAnswer->distributeValues($answerFromTcp)) {
                return false;
            }
        } else {
            echo "error check in answer";
            return false;
        }
        /*
         * Answer in a return or send FALSE in error.
         */
        unset($aReturnHotelStaticData, $aReturnRoomTypeStaticData, $aStaticInput, $answerFromTcp, $classCheck, $connector, $contructor, $inputObj, $port, $server, $string);
        return $mngAnswer::$answerStatic;
    }

    public function __destruct() {
        
    }

}

class Check {

    public function mandatoryTypeStaticInput(&$data) {
        $array = get_object_vars($data);
        $types = array('hotelIds' => 'array', 'ReturnHotelStaticData' => 'object', 'ReturnRoomTypeStaticData' => 'object');
        $mandatory = array('hotelIds' => true, 'ReturnHotelStaticData' => true, 'ReturnRoomTypeStaticData' => false);
        foreach ($mandatory as $key => $value) {
            if ($value) {
                if (!isset($array[$key])) {
                    return false;
                }
            }
        }
        foreach ($array as $key => $value) {
            if (isset($value)) {
                if (gettype($value) != $types[$key]) {
                    return false;
                }
            }
        }
        unset($array, $data, $key, $mandatory, $types, $value);
        return true;
    }

    public function mandatoryTypeReturnRoomTypeStaticData(&$data) {
        $array = get_object_vars($data);
        foreach ($array as $value) {
            if (isset($value)) {
                if (gettype($value) != 'boolean') {
                    return false;
                }
            }
        }
        unset($array, $data, $value);
        return true;
    }

    public function mandatoryTypeReturnHotelStaticData(&$data) {
        $array = get_object_vars($data);
        foreach ($array as $value) {
            if (isset($value)) {
                if (gettype($value) != 'boolean') {
                    return false;
                }
            }
        }
        unset($array, $data, $value);
        return true;
    }

    public function answer(&$data) {
        $arraypre = explode('|', $data);
        if (preg_match('/OK/', $arraypre[0])) {
            $array = array_splice($arraypre, 1);
            foreach ($array as $value) {
                $arrayExploded = explode(",", $value);
                if (count($arrayExploded) < 6) {
                    return false;
                }
            }
        } else {
            return false;
        }
        unset($array, $arrayExploded, $value, $data, $arraypre);
        return true;
    }

    public function __destruct() {
        
    }

}

class Constructor {

    Public $aStaticInput;
    Public $aReturnRoomTypeStaticData;
    Public $aReturnHotelStaticData;
    Public static $stringConverted = "";
    Public static $arrayConverted = array('hotelIds' => '', 'ReturnHotelStaticData' => '', 'ReturnRoomTypeStaticData' => '');

    function __construct($aStaticInput, $aReturnHotelStaticData = null, $aReturnRoomTypeStaticData = null) {
        $this->aStaticInput = $aStaticInput;
        $this->aReturnRoomTypeStaticData = $aReturnRoomTypeStaticData;
        $this->aReturnHotelStaticData = $aReturnHotelStaticData;
    }

    Public function insertVar() {
        $aStaticInput = get_object_vars($this->aStaticInput);
        $aReturnHotelStaticData = get_object_vars($this->aReturnHotelStaticData);
        if(isset($this->aReturnRoomTypeStaticData)){
        $aReturnRoomTypeStaticData = get_object_vars($this->aReturnRoomTypeStaticData);
        }
        $array_need = array();

        foreach ($aStaticInput['hotelIds'] as $key => $value) {
            $array_need[$key][] = $key;
            if (is_array($value)) {
                foreach ($value as $values) {
                    $array_need[$key][] = $values;
                }
            } else {
                $array_need[$key] = $value;
            }
        }
        self::$arrayConverted['hotelIds'] = $array_need;
        self::$arrayConverted['ReturnHotelStaticData'] = $aReturnHotelStaticData;
        self::$arrayConverted['ReturnRoomTypeStaticData'] = $aReturnRoomTypeStaticData;
        unset($aReturnHotelStaticData, $aReturnRoomTypeStaticData, $aStaticInput, $array_need, $key, $value, $values);
        return true;
    }

    Public function convertToBool() {
        //REPLACE BOOLEANS WITH y AND N
        foreach (self::$arrayConverted as $key => $value) {
            if (is_array($value)) {
                foreach ($value as $keyin => $valuein) {
                    if (is_array($valuein)) {
                        foreach ($valuein as $keyinin => $valueinin) {
                            $val = $valueinin;
                            if (gettype($val) == 'boolean') {
                                if ($val) {
                                    $val = 'Y';
                                } else {
                                    $val = 'N';
                                }
                                self::$arrayConverted[$key][$keyin][$keyinin] = $val;
                            }
                        }
                    } else {
                        $val = $valuein;
                        if (gettype($val) == 'boolean') {
                            if ($val) {
                                $val = 'Y';
                            } else {
                                $val = 'N';
                            }
                            self::$arrayConverted[$key][$keyin] = $val;
                        }
                    }
                }
            } else {
                $val = $value;
                if (gettype($val) == 'boolean') {
                    if ($val) {
                        $val = 'Y';
                    } else {
                        $val = 'N';
                    }
                    self::$arrayConverted[$key] = $val;
                }
            }
        }
        unset($key, $keyin, $keyinin, $val, $value, $valuein, $valueinin);
        return true;
    }

    Public function returnArray() {
        return self::$arrayConverted;
    }

    //INCLUDE IN GLUES THE SIGN TO SEPARATE VALUES by EXAMPLE array("|",",","~","#")
    public static function convertRequestArrayToString(array $glues, array $array) {
        $out = "";
        $g = array_shift($glues);
        $c = count($array);
        $i = 0;
        foreach ($array as $val) {
            if (is_array($val)) {
                $out .= self::convertRequestArrayToString($glues, $val);
            } else {
                $out .= (string) $val;
            }
            $i++;
            if ($i < $c) {
                $out .= $g;
            }
        }
        unset($i, $c, $g, $val, $array, $glues);
        return $out;
    }

    Public function returnString() {
        return self::$stringConverted;
    }

    public function __destruct() {
        
    }

}

class ConnectorTCP {

    Private $string;
    Private $server;
    Private $port;
    Public static $answer;

    function __construct($string, $server, $port) {
        $this->string = $string;
        $this->server = $server;
        $this->port = $port;
    }

    Public function requestTCP() {

        set_time_limit(0);
        $debug = false;
        $server = $this->server;
        $port = $this->port;
        $seconds = 3;
        $var = $this->string;
        $message = "HOTELDATAREQUEST |$var\r\n";
        $buffer = '';
        //////////////////////////////
        if (!($socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP))) {
            if ($debug) {
                $errorcode = socket_last_error();
                $errormsg = socket_strerror($errorcode);
                die("Couldn't create socket: [$errorcode] $errormsg \n");
            }
            return false;
        }
        if ($debug) {
            echo "Socket created \n";
        }
        //Connect socket to remote server
        socket_set_option($socket, SOL_SOCKET, SO_SNDTIMEO, array('sec' => 5, 'usec' => 0));
        if (!socket_connect($socket, $server, $port)) {
            if ($debug) {
                $errorcode = socket_last_error();
                $errormsg = socket_strerror($errorcode);
                die("Could not connect: [$errorcode] $errormsg \n");
            }
            return false;
        }
        if ($debug) {
            echo "Connection established \n";
        }
        //Send the message to the server
        if (!socket_send($socket, $message, strlen($message), 0)) {
            if ($debug) {
                $errorcode = socket_last_error();
                $errormsg = socket_strerror($errorcode);
                die("Could not send data: [$errorcode] $errormsg \n");
            }
            return false;
        } else {
            if ($debug) {
                echo "Message send successfully \n";
            }
        }
        //Connect socket to remote server
        socket_set_option($socket, SOL_SOCKET, SO_RCVTIMEO, array('sec' => 5, 'usec' => 0));
        while ($buf = socket_read($socket, 2048000, PHP_NORMAL_READ)) {
            if ($debug) {
                echo "Answer from server: $buffer";
            }
            break;
        }
        //IF NEED QUIT TO CLOSE SOCKET ENABLE IT
        /*
          $message = "QUIT\r\n";
          if( !socket_send ( $socket , $message , strlen($message) , 0))
          {
          $errorcode = socket_last_error();
          $errormsg = socket_strerror($errorcode);

          die("Could not send data: [$errorcode] $errormsg \n");
          } else {
          if ($debug) echo "Message QUIT send successfully \n";
          }
         */
        socket_close($socket);
        unset($message, $server, $port, $seconds, $debug, $socket, $errorcode, $errormsg, $buffer, $var);
        self::$answer = $buf;
        return true;
    }

    public function returnAnswerTCP() {
        return self::$answer;
    }

    public function __destruct() {
        
    }

}

class AnswerTreatment {

    public static $answerStatic = array();
    public static $HotelStaticData;
    public static $ImageData;
    public static $RoomInfo;
    public static $RoomTypeStaticData;
    public static $TransportationData;
    public static $types = array('string', 'string', 'string', 'string', 'boolean', 'array', 'boolean', 'integer', 'integer', 'integer', 'integer', 'boolean', 'string', 'string', 'string', 'string', 'integer', 'string', 'string', 'string', 'string', 'integer', 'string', 'integer', 'string', 'integer', 'string', 'integer', 'array', 'array', 'array', 'string', 'integer', 'integer', 'integer', 'integer', 'boolean', 'integer', 'string', 'array', 'array', 'array');
    public static $Labels = array('description1', 'description2', 'geoPoints', 'ratingDescription', 'direct', 'hotelPreference', 'preferred', 'builtYear', 'renovationYear', 'floors', 'noOfRooms', 'luxury', 'hotelName', 'address', 'zipCode', 'location', 'locationId', 'location1', 'location2', 'location3', 'cityName', 'cityCode', 'stateName', 'stateCode', 'countryName', 'countryCode', 'regionName', 'regionCode', 'amenitie', 'leisure', 'business', 'hotelPhone', 'hotelCheckIn', 'hotelCheckOut', 'minAge', 'rating', 'fireSafety', 'chain', 'lastUpdated', 'images', 'RoomTypeStaticDataList', 'transportation');
    public static $LabelsImages = array('thumb', 'alt', 'category', 'url');
    public static $LabelsTransportation = array('Name', 'Dist', 'DistanceUnit', 'DistTime', 'Directions');
    public static $LabelsRoomInfo = array('maxOccupancy', 'maxAdultWithChildren', 'minChildAge', 'maxChildAge', 'maxAdult', 'maxExtraBed', 'maxChildren');
    public static $LabelsRoomTypeStaticData = array('twin', 'roomAmenities', 'name', 'roomInfo');

    public function distributeValues($data) {
        $array_need = array();
        $stringarray = explode("|", $data);
        /*
         * Check if the ARRAY have information
         */
        if (count($stringarray) < 2) {
            return false;
        }
        /*
         * SPLICE THE OK VALUE FROM THE ARRAY
         */
        $array = array_splice($stringarray, 1);
        /*
         * Separate in information packets
         */
        foreach ($array as $key => $value) {
            $valuefinal = explode(",", $value);
//            print_r(count($valuefinal));
//            print_r($value);
//            echo "\n\r";
//            print_r(count(self::$Labels));
//            echo "\n\r";
            $hotelStaticData = new \Hotel\PreSupplier\HotelStaticData();
            for ($x = 0; $x < count($key); $x++) {
                for ($i = 0; $i < count($valuefinal); $i++) {
                    /*
                     * Check Mandatory values
                     */
                    if ($valuefinal[6] === NULL or $valuefinal[12] === NULL or $valuefinal[20] === NULL or $valuefinal[21] === NULL or $valuefinal[25] === NULL) {
                        echo "VALUE MANDATORY NO SET\n\r";
                        return false;
                    }
                    /*
                     * REMOVE "\r\n" from the last value
                     */
                    $valuefinal[41] = trim($valuefinal[41]);
                    /*
                     * Management object HOTELSTATICDATA
                     */
                    if (preg_match('/~/', $valuefinal[$i])) {
                        $array1 = explode('~', $valuefinal[$i]);
                        $var = self::$Labels[$i];
                        if (isset($valuefinal[$i]) and $valuefinal[$i] != ''){
                        $hotelStaticData->$var = $array1;
                        }
                    } else {
                        $var = self::$Labels[$i];
                        $type = self::$types[$i];
                        if ($type == 'integer') {
                            if (isset($valuefinal[$i]) and $valuefinal[$i] != '') {
                                $hotelStaticData->$var = (int) $valuefinal[$i];
                            }
                        } elseif ($type == 'boolean') {
                            if (isset($valuefinal[$i]) and $valuefinal[$i] != '') {
                                if ($valuefinal[$i] == 'Y') {
                                    $valuefinal[$i] = true;
                                } elseif ($valuefinal[$i] == 'N'){
                                    $valuefinal[$i] = false;
                                }
                            }
                            if (isset($valuefinal[$i]) and $valuefinal[$i] != '') {
                            $hotelStaticData->$var = $valuefinal[$i];
                            }
                        } else {
                            if (isset($valuefinal[$i]) and $valuefinal[$i] != '') {
                            $hotelStaticData->$var = $valuefinal[$i];
                            }
                        }
                    }
                }
            }
            /*
             * Management object IMAGES
             */
            if (isset($hotelStaticData->images) and is_array($hotelStaticData->images)) {
                $arrayImage = array();
                foreach ($hotelStaticData->images as $keyIn => $valueIn) {
                    $imageData = new \Hotel\PreSupplier\ImageData();
                    $array1 = explode('#', $valueIn);
                    foreach ($array1 as $keyInIn => $valueInIn) {
                        $labelImage = self::$LabelsImages[$keyInIn];
                        $imageData->$labelImage = $valueInIn;
                    }
                    $arrayImage[] = $imageData;
                }
                $hotelStaticData->images = $arrayImage;
            }
            /*
             * Management object Transportation
             */
            if (isset($hotelStaticData->transportation) and is_array($hotelStaticData->transportation)) {
                $transportationData = new \Hotel\PreSupplier\TransportationData();
                foreach ($hotelStaticData->transportation as $keytr => $valuetr) {
                    $labelTransportation = self::$LabelsTransportation[$keytr];
                    $transportationData->$labelTransportation = trim($valuetr);
                }
                $hotelStaticData->transportation = array($transportationData);
            }

            /*
             * Management object RoomTypeStaticDataList and the internal objects RoomINFO
             */
            if (isset($hotelStaticData->RoomTypeStaticDataList) and is_array($hotelStaticData->RoomTypeStaticDataList)) {
                $arrayRoomTypeStatic = array();
                foreach ($hotelStaticData->RoomTypeStaticDataList as $keytr => $valuetr) {
                    $roomTypeStaticData = new \Hotel\PreSupplier\RoomTypeStaticData;
                    if (preg_match('/#/', $valuetr)) {
                        $array1 = explode('#', $valuetr);
                        $roomInfo = new \Hotel\PreSupplier\RoomInfo();
                        foreach ($array1 as $keyIn => $valueIn) {
                            if (preg_match('/{/', $valueIn)) {
                                if (self::$LabelsRoomTypeStaticData[$keyIn] == 'roomInfo') {
                                    $arrayIn = explode('{', $valueIn);
                                    //$roomInfo = new \Hotel\PreSupplier\RoomInfo();
                                    foreach ($arrayIn as $keytr => $valuetr) {
                                        //$labelTransportation = self::$LabelsRoomInfo[$keytr];
                                        if (isset($valuetr)) {
                                            $labelRoomInfo = self::$LabelsRoomInfo[$keytr];
                                            if ($labelRoomInfo == 'maxExtraBed') {
                                                if ($valuetr == 'Y') {
                                                    $roomInfo->$labelRoomInfo = true;
                                                } elseif ($valuetr == 'N') {
                                                    $roomInfo->$labelRoomInfo = false;
                                                }
                                            } else {
                                                $roomInfo->$labelRoomInfo = (int) $valuetr;
                                            }
                                            $labelRoom = self::$LabelsRoomTypeStaticData[$keyIn];
                                            $roomTypeStaticData->$labelRoom = array($roomInfo);
                                        }
                                    }
                                } else {
                                    $arrayIn = array_map('intval', explode('{', $valueIn));
                                    $labelRoom = self::$LabelsRoomTypeStaticData[$keyIn];
                                    $roomTypeStaticData->$labelRoom = $arrayIn;
                                }
                            } else {
                                if (self::$LabelsRoomTypeStaticData[$keyIn] == 'twin') {
                                    if (isset($valueIn)) {
                                        if ($valueIn == 'Y') {
                                            $valueIn = true;
                                        } elseif ($valueIn == 'N') {
                                            $valueIn = false;
                                        } else {
                                            $valueIn = '';
                                        }
                                    }
                                    $labelRoom = self::$LabelsRoomTypeStaticData[$keyIn];
                                    $roomTypeStaticData->$labelRoom = $valueIn;
                                } else {
                                    $labelRoom = self::$LabelsRoomTypeStaticData[$keyIn];
                                    $roomTypeStaticData->$labelRoom = $valueIn;
                                }
                            }

                            //$arrayRoomTypeStatic[$keytr] =  $roomTypeStaticData;
                            $arrayRoomTypeStatic[$keytr] = $roomTypeStaticData;
                        }
                    } else {
                        echo "INCORRECT ROOMTYPESTATICDATALIST\n\r";
                        return false;
                    }
                    //$arrayRoomTypeStatic[$keytr] =  $roomTypeStaticData;
                    //$hotelStaticData->RoomTypeStaticDataList[$keyTr] = $roomTypeStaticData;  
                }
                $hotelStaticData->RoomTypeStaticDataList = $arrayRoomTypeStatic;
            }
            self::$answerStatic[$key] = $hotelStaticData;
        }
        unset($keytr, $valuetr, $valueIn, $array_need, $labelRoomInfo, $roomInfo, $array, $array1, $labelRoom, $data, $i, $arrayImage, $arrayIn, $arrayRoomTypeStatic, $hotelStaticData, $arrayRoomTypeStatic, $roomTypeStaticData, $transportationData, $labelTransportation);
        return true;
    }

    public function __destruct() {
        
    }

}
