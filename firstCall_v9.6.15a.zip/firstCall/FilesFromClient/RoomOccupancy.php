<?php


namespace Hotel\PreSupplier;


class RoomOccupancy
{

    public $adults;
    public $children = array();
    public $twin;
    public $extraBed;

}